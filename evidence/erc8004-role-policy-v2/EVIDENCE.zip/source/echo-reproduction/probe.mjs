// Executes pinned upstream Solidity, without reading expected outcomes.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import crypto from 'node:crypto';

const root = "D:\\PAVLO HQ\\Workspaces\\veca-erc8004-validator-policy-20261024";
const runtime = path.join(root, 'build/erc8004/runtime');
const sourceRoot = path.resolve(process.argv[2]);
const requireRuntime = createRequire(path.join(runtime, 'package.json'));
const ethers = requireRuntime('ethers');
const solc = requireRuntime('solc');
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const request = JSON.parse(fs.readFileSync(0, 'utf8'));
const sourceNames = ['HardhatMinimalUUPS', 'ERC1967Proxy', 'IdentityRegistryUpgradeable', 'ValidationRegistryUpgradeable'];
const sources = Object.fromEntries(sourceNames.map(n => [`contracts/${n}.sol`, {content: fs.readFileSync(path.join(sourceRoot, `contracts/${n}.sol`), 'utf8')}]));
const compileInput = {language: 'Solidity', sources, settings: {evmVersion: 'shanghai', optimizer: {enabled: true, runs: 200}, outputSelection: {'*': {'*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object']}}}};
const compiled = JSON.parse(solc.compile(JSON.stringify(compileInput), {import: name => {
  const filename = path.join(runtime, 'node_modules', name);
  return fs.existsSync(filename) ? {contents: fs.readFileSync(filename, 'utf8')} : {error: `missing import ${name}`};
}}));
const errors = (compiled.errors ?? []).filter(e => e.severity === 'error');
if (errors.length) throw Error(JSON.stringify(errors));
process.chdir(runtime);
const {network} = await import(pathToFileURL(requireRuntime.resolve('hardhat')).href);
const connection = await network.connect('laboratory');
const rpc = connection.provider;
// Wall-clock time must not affect signatures, receipts or replay evidence.
const originalRequest = rpc.request.bind(rpc);
rpc.request = async args => {
  if (args.method === 'eth_sendTransaction' || args.method === 'eth_sendRawTransaction') {
    const block = await originalRequest({method:'eth_getBlockByNumber', params:['latest',false]});
    await originalRequest({method:'evm_setNextBlockTimestamp', params:[Number(BigInt(block.timestamp))+1]});
  }
  return originalRequest(args);
};
const provider = new ethers.BrowserProvider(rpc, undefined, {cacheTimeout: -1});
provider.pollingInterval = 10;
const signers = await Promise.all([0,1,2,3].map(n => provider.getSigner(n)));
const addresses = await Promise.all(signers.map(s => s.getAddress()));
const artifacts = Object.fromEntries(sourceNames.map(n => [n, compiled.contracts[`contracts/${n}.sol`][n]]));
async function deploy(name, args=[]) {
  const a=artifacts[name];
  const c=await new ethers.ContractFactory(a.abi, a.evm.bytecode.object, signers[0]).deploy(...args);
  await c.waitForDeployment(); return c;
}
const minimal = await deploy('HardhatMinimalUUPS');
async function registry(name, init) {
  const proxy = await deploy('ERC1967Proxy', [minimal.target, minimal.interface.encodeFunctionData('initialize', [ethers.ZeroAddress])]);
  const impl = await deploy(name);
  const iface = new ethers.Interface(artifacts[name].abi);
  await (await new ethers.Contract(proxy.target, artifacts.HardhatMinimalUUPS.abi, signers[0]).upgradeToAndCall(impl.target, iface.encodeFunctionData('initialize', init))).wait();
  return {contract: new ethers.Contract(proxy.target, artifacts[name].abi, signers[0]), implementation: impl.target};
}
const identity = await registry('IdentityRegistryUpgradeable', []);
const validation = await registry('ValidationRegistryUpgradeable', [identity.contract.target]);
const id = identity.contract, val = validation.contract;
await (await id['register(string)']('data:application/json;base64,e30=')).wait();
await (await id['register(string)']('data:application/json;base64,e30=')).wait();
const requestPayload = ethers.toUtf8Bytes('{"agent":0,"job":"laboratory-validation"}');
const requestHash = ethers.keccak256(requestPayload);
const responseHash = ethers.keccak256(ethers.toUtf8Bytes('laboratory validator assertion'));
let snapshot = await rpc.request({method:'evm_snapshot'});
const observations = {};
const txOptions = {gasLimit: 3000000};
async function transact(fn) {
  let receipt;
  try { receipt = await (await fn()).wait(); }
  catch (error) { if (error.receipt?.status !== 0) throw error; receipt = error.receipt; }
  const raw = await rpc.request({method:'eth_getTransactionReceipt', params:[receipt.hash]});
  const tx = await rpc.request({method:'eth_getTransactionByHash', params:[receipt.hash]});
  return {status: receipt.status === 1 ? 'ACCEPTED' : 'REJECTED', transaction: tx, receipt: raw};
}
// Scenario extension evaluated inside the pinned v0 local EVM runtime.
// Receives inputs only, never vectors/obligations/expected outcomes.
for (const test of request.cases) {
  if (!await rpc.request({method:'evm_revert', params:[snapshot]})) throw Error('snapshot restore failed');
  snapshot = await rpc.request({method:'evm_snapshot'});
  const op = test.input.operation;
  if (op.kind !== 'respond_validation') throw Error('unsupported operation');
  const subject = BigInt(op.agent_id);
  const validator = addresses[op.validator];
  if (!validator || !signers[op.actor]) throw Error('unknown laboratory actor');
  if (op.role === 'operator') await (await id.setApprovalForAll(validator, true, txOptions)).wait();
  else if (op.role === 'approved') await (await id.approve(validator, subject, txOptions)).wait();
  else if (op.role !== 'none') throw Error('unsupported setup role');

  let walletUpdate = null;
  if (op.wallet_probe) {
    const block = await rpc.request({method:'eth_getBlockByNumber',params:['latest',false]});
    const deadline = Number(BigInt(block.timestamp)) + 240;
    const domain = {name:'ERC8004IdentityRegistry',version:'1',chainId:31337,verifyingContract:id.target};
    const types = {AgentWalletSet:[{name:'agentId',type:'uint256'},{name:'newWallet',type:'address'},{name:'owner',type:'address'},{name:'deadline',type:'uint256'}]};
    const value = {agentId:op.agent_id,newWallet:validator,owner:await id.ownerOf(subject),deadline};
    const signature = await signers[op.validator].signTypedData(domain,types,value);
    const result = await transact(() => id.setAgentWallet(subject,validator,deadline,signature,txOptions));
    if (result.status !== 'ACCEPTED') throw Error('valid wallet signature rejected');
    walletUpdate = {...result,domain,types,value,signature,recovered:ethers.verifyTypedData(domain,types,value,signature)};
  }

  const requested = await transact(() => val.validationRequest(validator, subject, 'ipfs://laboratory-role-policy', requestHash, txOptions));
  if (requested.status !== 'ACCEPTED') throw Error('request setup failed');
  // Query the request block, not response-time state; use the same fixed block
  // for owner, global approval and token approval. No intervening transaction.
  const blockTag = Number(BigInt(requested.receipt.blockNumber));
  const owner = await id.ownerOf(subject, {blockTag});
  const requestRoles = {owner, validator, approved: await id.getApproved(subject, {blockTag}),
    operator: await id.isApprovedForAll(owner, validator, {blockTag}), agent_id: op.agent_id,
    request_hash: requestHash, block_number: requested.receipt.blockNumber, block_hash: requested.receipt.blockHash};
  if (op.after === 'revoke_operator') await (await id.setApprovalForAll(validator, false, txOptions)).wait();
  else if (op.after === 'revoke_approved') await (await id.approve(ethers.ZeroAddress, subject, txOptions)).wait();
  else if (op.after === 'grant_operator') await (await id.setApprovalForAll(validator, true, txOptions)).wait();
  else if (op.after === 'grant_approved') await (await id.approve(validator, subject, txOptions)).wait();
  else if (op.after === 'transfer_away') await (await id.transferFrom(addresses[0], addresses[3], subject, txOptions)).wait();
  else if (op.after === 'transfer_to_validator') await (await id.transferFrom(addresses[0], validator, subject, txOptions)).wait();
  else if (op.after !== 'none') throw Error('unsupported role transition');
  if (op.update) await (await val.connect(signers[op.validator]).validationResponse(requestHash,50,'',responseHash,'soft',txOptions)).wait();
  const result = await transact(() => val.connect(signers[op.actor]).validationResponse(requestHash,100,'',responseHash,'final',txOptions));
  const status = await val.getValidationStatus(requestHash);
  const responseOwner = await id.ownerOf(subject);
  const responseRoles = {owner:responseOwner,validator,approved:await id.getApproved(subject),
    operator:await id.isApprovedForAll(responseOwner,validator),agent_id:op.agent_id,
    request_hash:requestHash,block_number:result.receipt.blockNumber,block_hash:result.receipt.blockHash};
  observations[test.id] = {...result, state:status[2] === 100n ? 'RESPONSE_RECORDED' : 'RESPONSE_ABSENT',
    chain_id:31337, registry_role:'validation', registry_address:val.target, agent_id:op.agent_id,
    validator:status[0], actors:addresses, request_hash:requestHash, response_hash:responseHash,
    request_payload_hex:ethers.hexlify(requestPayload), request_receipt:requested.receipt,
    request_transaction:requested.transaction, wallet_update:walletUpdate, wallet_at_request:await id.getAgentWallet(subject,{blockTag}), request_roles:requestRoles, response_roles:responseRoles};
}

const output={observations,runtime:{node:process.version,solc:solc.version(),hardhat:'3.0.6',evm:'shanghai',chain_id:31337,
  source_sha256:Object.fromEntries(Object.entries(sources).map(([n,v])=>[n,sha(Buffer.from(v.content))])),
  compiler_input_sha256:sha(Buffer.from(JSON.stringify(compileInput))),
  identity_implementation:identity.implementation,validation_implementation:validation.implementation,
  identity_codehash:ethers.keccak256(await provider.getCode(identity.implementation)),validation_codehash:ethers.keccak256(await provider.getCode(validation.implementation)),
  deployment_method:'upstream HardhatMinimalUUPS bootstrap -> real UUPS registry implementation; local EDR only'}};
await connection.close();
process.stdout.write(JSON.stringify(output));
