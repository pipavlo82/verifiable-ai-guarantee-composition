"""Record sequential suites; never overlap cache-destructive infrastructure tests."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
INTEGRATION=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')


def run(root,group,commands):
    out=root/'build/role-policy-v2'/group
    out.mkdir(parents=True,exist_ok=True)
    records=[]
    for name,args in commands:
        argv=[sys.executable,'-B',*args]
        with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
            code=subprocess.call(argv,cwd=root,stdout=stdout,stderr=stderr)
        record={'name':name,'argv':argv,'cwd':str(root),'exit_code':code,
                'stdout_sha256':hashlib.sha256((out/(name+'.stdout')).read_bytes()).hexdigest(),
                'stderr_sha256':hashlib.sha256((out/(name+'.stderr')).read_bytes()).hexdigest()}
        records.append(record)
        (out/'commands.json').write_bytes((json.dumps(records,indent=2,sort_keys=True)+'\n').encode())
        print(name,code,flush=True)
        if code: raise RuntimeError(name+' failed; inspect retained logs')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('group',choices=['source','composition','final-v2'])
    args=p.parse_args()
    if args.group=='source':
        commands=[('v2',['tools/erc8004_role_policy_v2/validate.py']),
          ('legacy',['tools/erc8004/validate.py','--out','build/role-policy-v2/legacy']),
          ('legacy-optimized',['-O','tools/erc8004/mutations.py','--out','build/role-policy-v2/legacy-optimized']),
          ('v1',['tools/erc8004_role_policy/validate.py','--out','build/role-policy-v2/v1']),
          ('baseline',['-m','unittest','discover','-s','tests/baseline_reconciliation','-v']),
          ('baseline-optimized',['-O','-m','unittest','discover','-s','tests/baseline_reconciliation','-v']),
          ('inventory',['tools/verify_artifacts.py'])]
        run(ROOT,'source-commands',commands)
    elif args.group=='final-v2':
        prior=json.loads((ROOT/'build/role-policy-v2/source-commands/commands.json').read_bytes())
        if not all(any(r['name']==name and r['exit_code']==0 for r in prior) for name in ('legacy','legacy-optimized')):
            raise RuntimeError('legacy cache-changing controls must finish before parallel v2 replay')
        run(ROOT,'final-v2-commands',[('v2',['tools/erc8004_role_policy_v2/validate.py'])])
    else:
        commands=[('preservation',['tools/erc8004_role_policy_v2/integrity.py']),
          ('legacy',['tools/erc8004/validate.py','--out','build/role-policy-v2/legacy']),
          ('legacy-optimized',['-O','tools/erc8004/mutations.py','--out','build/role-policy-v2/legacy-optimized']),
          ('v1',['tools/erc8004_role_policy/validate.py','--out','build/role-policy-v2/v1']),
          ('v2',['tools/erc8004_role_policy_v2/validate.py']),
          ('harness',['tools/harness_v0/validate.py','--out','build/role-policy-v2/harness']),
          ('harness-optimized',['-O','tools/harness_v0/mutations.py','--out','build/role-policy-v2/harness-optimized']),
          ('pr11',['tools/harness_v0/review_validate.py','--out','build/role-policy-v2/pr11']),
          ('inventory',['tools/verify_artifacts.py'])]
        run(INTEGRATION,'composition-commands',commands)
