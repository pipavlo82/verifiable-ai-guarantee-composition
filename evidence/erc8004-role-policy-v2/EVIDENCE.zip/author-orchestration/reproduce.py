"""Isolated actual-contract reproduction; leaves every v1 source byte untouched."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
OUT = ROOT / 'build/role-policy-v2/echo-reproduction'
OUT.mkdir(parents=True, exist_ok=True)
def save(name, value):
    (OUT / name).write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

review = subprocess.check_output(['gh', 'api', 'repos/trustless-ai/verifiable-execution-claim-authorization/issues/comments/6382807754'])
(OUT / 'echo-review.json').write_bytes(review)
original = (ROOT / 'tools/erc8004/evm.mjs').read_bytes()
if hashlib.sha256(original).hexdigest() != '995e957138979c936a29d1251c357a3ca2e8d8a09b46aa48ab2dec7221be1193':
    raise RuntimeError('frozen source mismatch')
source = original.decode()
start = source.index('for (const test of request.cases) {')
end = source.index('const output={observations,runtime:')
prefix = source[:start].replace("const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');", 'const root = ' + json.dumps(str(ROOT)) + ';')
body = (ROOT / 'tools/erc8004_role_policy/scenarios.mjs').read_text()
probe = '''
  let walletUpdate = null;
  if (op.wallet_probe) {
    const block = await rpc.request({method:'eth_getBlockByNumber',params:['latest',false]});
    const deadline = Number(BigInt(block.timestamp)) + 240;
    const domain = {name:'ERC8004IdentityRegistry',version:'1',chainId:31337,verifyingContract:id.target};
    const types = {AgentWalletSet:[{name:'agentId',type:'uint256'},{name:'newWallet',type:'address'},{name:'owner',type:'address'},{name:'deadline',type:'uint256'}]};
    const value = {agentId:op.agent_id,newWallet:validator,owner:await id.ownerOf(subject),deadline};
    const signature = await signers[op.validator].signTypedData(domain,types,value);
    const result = await transact(() => id.setAgentWallet(subject,validator,deadline,signature,txOptions));
    if (result.status !== 'ACCEPTED') throw Error('valid wallet signature rejected');
    walletUpdate = {...result,domain,types,value,signature,recovered:ethers.verifyTypedData(domain,types,value,signature)};
  }
'''
body = body.replace('  const requested =', probe + '\n  const requested =', 1)
body = body.replace('request_transaction:requested.transaction,', 'request_transaction:requested.transaction, wallet_update:walletUpdate, wallet_at_request:await id.getAgentWallet(subject,{blockTag}),', 1)
launcher = OUT / 'probe.mjs'
launcher.write_bytes((prefix + body + '\n' + source[end:]).encode())
vectors = json.loads((ROOT / 'conformance/erc8004-role-policy-v1/vectors.json').read_bytes())['vectors']
by_name = {row['name']: row for row in vectors}
cases = [{'id': name, 'input': copy.deepcopy(by_name[name]['input'])} for name in ('separate_validator', 'owner_self')]
probe_case = copy.deepcopy(cases[0]); probe_case['id'] = 'agent_wallet_self'; probe_case['input']['operation']['wallet_probe'] = True
cases.append(probe_case)
request = {'schema':'agent-harness.request.v0', 'profile':'erc8004-validator-role-separation-v1', 'cases':cases}
save('request.json', request)
argv = ['node', str(launcher), str(ROOT / 'build/erc8004/implementation')]
proc = subprocess.run(argv, input=json.dumps(request).encode(), cwd=ROOT, capture_output=True, timeout=180)
(OUT / 'evm.stdout').write_bytes(proc.stdout); (OUT / 'evm.stderr').write_bytes(proc.stderr)
save('command.json', {'argv':argv,'cwd':str(ROOT),'exit_code':proc.returncode})
if proc.returncode: raise RuntimeError(proc.stderr.decode())
sys.path.insert(0, str(ROOT / 'tools'))
from erc8004_role_policy.policy import evaluate
from erc8004.adapter import authorize
executed = json.loads(proc.stdout)
results = {}
for case in cases:
    observation = executed['observations'][case['id']]
    status, scope, reason = evaluate(case['input'], observation, authorize)
    results[case['id']] = {'status':status,'reason':reason,'scope':scope,'request_roles':observation['request_roles'],
        'agent_wallet_at_request':observation['wallet_at_request'], 'wallet_update':observation['wallet_update']}
if [(v['status'],v['reason']) for v in results.values()] != [('VERIFIED','REQUEST_TIME_ROLE_SEPARATION'),('UNVERIFIABLE','SELF_ATTESTED_OWNER'),('VERIFIED','REQUEST_TIME_ROLE_SEPARATION')]:
    raise RuntimeError('reproduction did not match the reviewed boundary')
save('result.json', {'schema':'erc8004.agent-wallet-v1-boundary.v0','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'evidence_source':'LOCAL_AUTHOR_ACTUAL_PINNED_CONTRACT_EXECUTION','results':results,'runtime':executed['runtime'],
    'interpretation':'Coverage boundary of v1, not an ERC-8004 vulnerability; expected outcomes never supplied to EVM.'})
print(json.dumps({k:{'status':v['status'],'reason':v['reason'],'wallet':v['agent_wallet_at_request']} for k,v in results.items()},indent=2))
