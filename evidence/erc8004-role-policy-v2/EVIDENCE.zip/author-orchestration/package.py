"""Package actual completed runs only; retain preliminary runs as non-closure."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile
from datetime import datetime,timezone

HERE=Path(__file__).resolve().parent
SOURCE=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
COMPOSED=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')
RUN=Path('build/role-policy-v2')
DEST=SOURCE/'evidence/erc8004-role-policy-v2'
DOCS=SOURCE/'research/erc8004-role-policy-v2'
EXPECTED={'legacy':'837dbe977cb3bf66470ffe7ed2b4311e001776bbed95057f3b366d16af25e211',
          'v1':'0ed522131509603602adbb90d8c6111a3347d8b5c19ce90d75440c67953a7617',
          'harness':'1c12db717dc43d6b9568b902089cde8906e53951aa2ccf22e4b04404620a106b',
          'pr11':'aa134ea900784fbb4f69d972babafa1b579b64e16771de554f906ef47dd909cc'}
def read(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
def require(ok,message):
    if not ok:raise RuntimeError(message)
def mutation(path,count):
    value=read(path);require(value['counts']['KILLED']==count and sum(value['counts'].values())==count,str(path));return value
def modes(folder,expected=None):
    projections={m:sha((folder/m/'projected.json').read_bytes()) for m in ('normal','repeat','optimized')}
    complete={m:sha((folder/m/'adapter.stdout').read_bytes()) for m in ('normal','repeat','optimized')}
    require(len(set(projections.values()))==len(set(complete.values()))==1,'complete mode disagreement:'+str(folder))
    if expected: require(set(projections.values())=={expected},'historical projection changed:'+str(folder))
    return {'behavioral_sha256':projections,'complete_observation_sha256':complete}

results={}
final_commands=read(SOURCE/RUN/'final-v2-commands/commands.json')
require(len(final_commands)==1 and final_commands[0]['exit_code']==0,'final classifier replay unfinished')
for label,root,group,required in [('source',SOURCE,'source-commands',7),('composition',COMPOSED,'composition-commands',9)]:
    commands=read(root/RUN/group/'commands.json')
    require(len(commands)==required and all(c['exit_code']==0 for c in commands),'unfinished '+label)
    legacy=read(root/RUN/'legacy/summary.json');v1=read(root/RUN/'v1/summary.json');v2=read(root/RUN/'validation/summary.json')
    require(legacy['passed'] and legacy['scenarios']==legacy['conformant']==29,'legacy failed')
    require(v1['passed'] and v1['cases']==v1['conformant']==26 and v1['controls']=={'normal':18,'optimized':18},'v1 failed')
    require(v2['passed'] and v2['cases']==v2['conformant']==v2['distinct_inputs']==50 and v2['controls']=={'normal':36,'optimized':36},'v2 failed')
    a=mutation(root/RUN/'legacy/mutations/report.json',17);b=mutation(root/RUN/'legacy-optimized/report.json',17)
    require(a==b,'legacy mutation mode difference')
    for suite,count in [('v1',7),('validation',5)]:
        a=mutation(root/RUN/suite/'mutations-normal/report.json',count)
        b=mutation(root/RUN/suite/'mutations-optimized/report.json',count)
        require(a==b,'policy mutation mode difference')
    preserve=read(root/RUN/'validation/preservation-after.stdout')
    require(preserve['passed'] and preserve['historical_files']==12703,'source preservation')
    results[label]={'legacy':{k:legacy[k] for k in ('passed','scenarios','conformant','mutations','authorization_counts')},
                    'legacy_determinism':modes(root/RUN/'legacy',EXPECTED['legacy']),
                    'v1':v1,'v1_complete_determinism':modes(root/RUN/'v1',EXPECTED['v1']),
                    'v2':v2,'v2_complete_determinism':modes(root/RUN/'validation'),'preservation':preserve}
for suite in ('legacy_determinism','v1_complete_determinism','v2_complete_determinism'):
    require(results['source'][suite]==results['composition'][suite],'source/composition mismatch: '+suite)
for name in ('baseline','baseline-optimized'):
    log=(SOURCE/RUN/'source-commands'/(name+'.stderr')).read_text()
    require('Ran 16 tests' in log and log.rstrip().endswith('OK'),'baseline unit controls')
harness=read(COMPOSED/RUN/'harness/summary.json');review=read(COMPOSED/RUN/'pr11/summary.json')
require(harness['passed'] and harness['scenario_count']==harness['conformant_scenarios']==18,'original ERC8404 scenarios')
require(mutation(COMPOSED/RUN/'harness/mutations/report.json',12)==mutation(COMPOSED/RUN/'harness-optimized/report.json',12),'harness mode difference')
harness_determinism=modes(COMPOSED/RUN/'harness',EXPECTED['harness'])
require(review['passed'] and review['scenario_count']==5 and review['isolated_mutation_counts']=={'KILLED':4},'PR11 witnesses')
require(review['reviewer_experiment_counts']=={'KILLED':1,'SURVIVED':4},'historical five-probe distinction')
review_digests={mode+'/'+repeat:sha((COMPOSED/RUN/'pr11'/mode/repeat/'projected.json').read_bytes())
                for mode in ('normal','optimized') for repeat in ('normal','repeat')}
require(set(review_digests.values())=={EXPECTED['pr11']},'PR11 historical digest changed')
candidate=read(COMPOSED/RUN/'candidate-composition.json')
for name,digest in candidate['copied'].items():
    require(sha((SOURCE/name).read_bytes())==digest and sha((COMPOSED/name).read_bytes())==digest,'tested source changed:'+name)
corpus=read(SOURCE/'conformance/erc8004-role-policy-v2/vectors.json')['vectors']
reference_claim=next(v['input']['claim'] for v in corpus if v['name']=='separate_validator')
populations={'policy_cases':len(corpus),'distinct_operation_configurations':len({encode(v['input']['operation']) for v in corpus}),
             'evidence_fault_cases':sum('evidence_control' in v['input'] for v in corpus),
             'claim_admission_controls':sum(v['input']['claim']!=reference_claim for v in corpus)}
require(populations=={'policy_cases':50,'distinct_operation_configurations':22,'evidence_fault_cases':22,'claim_admission_controls':6},'unexpected case populations')
summary={'schema':'erc8004.role-policy-evidence.v2','passed':True,'captured_utc':datetime.now(timezone.utc).isoformat(),
    'source_parent':'4799a7260d8f99e489541cffe471e53c50411459','pr_base':'25f7c45f20cfd4f892f7387cd3d3842105d8b214',
    'candidate':candidate,'runs':results,'case_populations':populations,'baseline_controls':{'normal':16,'optimized':16},
    'erc8404':{'cases':18,'mutations_normal':{'KILLED':12},'mutations_optimized':{'KILLED':12},'determinism':harness_determinism},
    'pr11':{'cases':5,'guards':['scope','scenario','definitions','supported_contract'],'physical_mutants':4,
             'historical_probe_comparison':review['reviewer_experiment_counts'],'behavioral_sha256':review_digests},
    'boundary':read(SOURCE/RUN/'validation/boundary-normal/result.json'),
    'evidence_source':'AUTHOR_OPERATED_WINDOWS_CANDIDATE_EXECUTION',
    'independent_review_of_final_head':'NOT_COVERED','public_chain_authentication':'NOT_COVERED',
    'independent_human_or_organizational_control':'NOT_COVERED',
    'fresh_committed_checkout_and_ci':'Recorded separately after commit; not asserted by this candidate archive.',
    'recommendation':'READY_FOR_INDEPENDENT_REVIEW'}
members={}
def add_tree(prefix,folder):
    require(folder.is_dir(),'missing evidence tree:'+str(folder))
    for path in sorted(folder.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
            members[prefix+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
for label,root in [('source',SOURCE),('composition',COMPOSED)]:
    add_tree(label,root/RUN)
members['SUMMARY.json']=encode(summary)
for name,digest in candidate['copied'].items():members['tested-source/'+name]=(SOURCE/name).read_bytes()
for name in ('run.py','compose.py','reproduce.py','package.py','state.py','PREFLIGHT.json'):
    members['author-orchestration/'+name]=(HERE/name).read_bytes()
for name in ('conformance/erc8004-pilot-v0/source-lock.json','conformance/erc8004-pilot-v0/package-lock.json',
             'conformance/erc8004-role-policy-v1/source-lock.json','conformance/agent-harness-v0/source-lock.json'):
    members['historical-source-locks/'+name]=(SOURCE/name).read_bytes()
for kind in ('implementation','specification'):
    add_tree('pinned-sources/'+kind,SOURCE/'build/erc8004'/kind)
require(not any('node_modules' in name or name.endswith('.pyc') for name in members),'unexpected cache')
DEST.mkdir(parents=True,exist_ok=True)
(DEST/'SUMMARY.json').write_bytes(encode(summary))
with zipfile.ZipFile(DEST/'EVIDENCE.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(members.items()):
        info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,raw)
seal={'schema':'erc8004.role-policy-evidence.hashes.v2','archive_sha256':sha((DEST/'EVIDENCE.zip').read_bytes()),
      'archive_bytes':(DEST/'EVIDENCE.zip').stat().st_size,'summary_sha256':sha((DEST/'SUMMARY.json').read_bytes()),
      'members':{name:sha(raw) for name,raw in sorted(members.items())}}
(DEST/'SHA256.json').write_bytes(encode(seal))
with zipfile.ZipFile(DEST/'EVIDENCE.zip') as archive:
    require(set(archive.namelist())==set(seal['members']),'archive member set')
    require(all(sha(archive.read(name))==digest for name,digest in seal['members'].items()),'archive member integrity')
(DEST/'README.md').write_bytes(b'''# AgentWallet role policy v2 execution evidence

New author-operated Windows evidence; historical v0/v1 packages remain unchanged.
SUMMARY.json identifies tested candidate code hashes and both parent trees.
EVIDENCE.zip contains actual requests, raw observations, grader reports, command
receipts, source pins, original Echo reproduction, normal/repeat/-O comparisons,
and every mutation's baseline/positive/mutated/restored evidence. Deterministic
ZIP ordering/timestamps and SHA256.json protect all members. Dependencies/caches
are excluded. Timing and absolute path metadata in raw results are preserved.

The development-mutations folder is explicitly NOT a successful final campaign:
its final preservation guard detected a concurrent author refinement of the source.
DEVELOPMENT_NOTES.json explains this exit 1. Final validation uses the frozen source
and is kept under validation; no preliminary failure is relabeled a pass.
The completed pre-classifier-refinement run is also retained separately. The final
classifier labels incomplete required behavior as MISSING_OUTPUT, not SURVIVED;
both are non-kills. Final source validation was rerun after that refinement.

Fresh committed-checkout and exact-head GitHub CI results are recorded separately
after the commit, not invented inside this pre-commit archive. Author replay does
not imply independent organizational acceptance. See the versioned research README
for exact dependency preparation and replay commands.
''')
v2=results['source']['v2'];digest=v2['behavioral_sha256']['normal'];whole=v2['complete_observation_sha256']['normal']
(DOCS/'RESULTS.md').write_bytes(f'''# Executed results: agentWallet role policy v2

Starting reviewed source: `4799a7260d8f99e489541cffe471e53c50411459`.
Evidence source: author-operated Windows execution on the source candidate and
isolated composition with PR #11. Exact candidate file hashes and parent refs are
in [SUMMARY.json](../../evidence/erc8004-role-policy-v2/SUMMARY.json).

## Before and after

A valid EIP-712 signature from validator `0x70997970C51812dc3A010C7d01b50e0d17dc79C8`
was used by the owner to call the actual pinned `setAgentWallet` before requesting
validation. The contract accepted the update and `getAgentWallet` at the request
block equaled the validator. Unchanged v1 returned `VERIFIED /
REQUEST_TIME_ROLE_SEPARATION`. Separate v2 returns `UNVERIFIABLE /
SELF_ATTESTED_AGENT_WALLET` on the same recorded execution. Positive separate-validator
and owner-self controls remain correct. No defect in the upstream ERC is claimed.

Pinned contract commit: `b9e466c250744a7e06b13dff9d3c2844ed64f825`.
IdentityRegistryUpgradeable SHA256:
`18c8ca8c88493b46e54d000c96eaf7470d1f9dbfe55493fd7fa923bae543ff75`.
Raw evidence includes typed-data domain/value/signature, recovered signer, transaction,
receipt, pre/post wallet values, four ABI call records at each receipt block,
compiler-input hash and deployed implementation code hashes.

| Separate population | Source candidate | Composition with #11 |
| --- | --- | --- |
| Original ERC-8004 v0 | 29/29, normal/repeat/-O | 29/29, normal/repeat/-O |
| Original v0 physical mutations | 17/17 normal and -O | 17/17 normal and -O |
| Historical role policy v1 | 26/26, normal/repeat/-O | 26/26, normal/repeat/-O |
| V1 physical mutations | 7/7 normal and -O | 7/7 normal and -O |
| New role policy v2 | 50/50 distinct inputs, normal/repeat/-O | 50/50, normal/repeat/-O |
| New v2 physical mutations | 5/5 normal and -O | 5/5 normal and -O |
| New unit/control methods | 36/36 normal and -O | 36/36 normal and -O |
| Frozen ERC-8404 harness | 18/18 in legacy regression | 18/18 normal/repeat/-O; separate 12/12 mutants in both modes |
| PR #11 supplemental profile | Present on the composed base | 5/5 including positive + four witnesses; separate 4/4 mutants in both modes |

V1 infrastructure controls remain 18/18 per mode. Existing baseline reconciliation
controls pass 16/16 normal and -O. PR #11's historical five-probe comparison stays
**1 KILLED / 4 SURVIVED**, separate from its four new distinguishing witnesses.
These populations are not combined into one mutation denominator.

V2 authorizations: {v2['authorization_counts']}. Every declared expectation matches;
registry execution success is separate from downstream research-policy authorization.
The 50 cases comprise 22 operation configurations, six claim-admission controls and
22 evidence-fault controls. All cases execute pinned contracts, but repeated EVM
setups for evidence faults are not claimed as 50 distinct contract transitions.
All five physical mutants are KILLED with healthy positives, identical requests,
byte-exact source restoration and complete raw-observation restoration. SURVIVED,
CRASHED, NO_OP, NOT_APPLIED, MISSING_OUTPUT, CONTROL_BROKEN, RESTORATION_FAILED
and UNVERIFIABLE are each zero in the final campaigns.

V2 complete behavioral SHA256: `{digest}`.
V2 complete adapter-observation SHA256: `{whole}`.
Both hashes match normal/repeat/-O and source/composed executions. Original v0 and
v1 complete behavioral digests remain `{EXPECTED['legacy']}` and
`{EXPECTED['v1']}`. The original ERC-8404 and PR #11 digests remain
`{EXPECTED['harness']}` and `{EXPECTED['pr11']}`.

All 12,703 files inventoried at the reviewed source HEAD remain byte-identical on
the source branch. The composed tree retains the existing exact two-document #11
transition and all 13 frozen supplemental payload files; its remaining 12,701
reviewed-source files are identical. The old reconciliation policy is unchanged.
Historical source locks, v0/v1 fixtures, reports, archives, ERC-8404 six-field Core,
harness transport and pinned recompute-kit grader remain unchanged.

Runtime: Python {v2['python'].split()[0]}, Node {v2['node']}, {v2['platform']}.
Archive SHA256: `{seal['archive_sha256']}`; {len(members)} members,
{seal['archive_bytes']} bytes. See [member hashes](../../evidence/erc8004-role-policy-v2/SHA256.json).

A preliminary mutation run ended with exit 1 because its preservation guard detected
an author edit to the source during development. Its five intermediate semantic
records are not final closure evidence. It is retained separately with an explanation;
all reported final campaigns started after code freeze and completed successfully.
The later completed pre-classifier-refinement run is retained separately as well:
incomplete behavior is now classified MISSING_OUTPUT instead of SURVIVED. Neither
classification is a kill. Final source validation was fully rerun after this change.

Recommendation: **READY_FOR_INDEPENDENT_REVIEW** for this finite v2 candidate.
Fresh committed-checkout and Linux CI results are recorded after commit separately
on the PR and in publication evidence. No new independent review, macOS replay,
ERC-1271 campaign, organizational independence, public-chain authentication,
judgment truth, production authorization or universal compliance is established.
PR #10 stays Draft; main, #12 and #13 remain outside this change.
'''.encode())
print(json.dumps({'passed':True,'archive_sha256':seal['archive_sha256'],'members':len(members),'bytes':seal['archive_bytes']}))
