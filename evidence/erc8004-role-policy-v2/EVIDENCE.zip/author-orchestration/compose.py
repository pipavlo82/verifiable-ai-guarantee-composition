"""Copy only the authorized additive v2 payload onto the existing isolated PR tree."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
DEST=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')
expected='e0433f832821e2de4c0079633bda03ffbfdebd47'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=DEST,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=DEST,text=True)
if head!=expected or status: raise RuntimeError('integration checkout not the preserved clean starting tree')
paths=['tools/erc8004_role_policy_v2','conformance/erc8004-role-policy-v2','tests/erc8004_role_policy_v2',
       'research/erc8004-role-policy-v2','.github/workflows/erc8004-role-policy-v2.yml']
copied={}
for prefix in paths:
    source=ROOT/prefix
    for path in ([source] if source.is_file() else sorted(source.rglob('*'))):
        if not path.is_file() or '__pycache__' in path.parts: continue
        relative=path.relative_to(ROOT)
        target=DEST/relative
        if target.exists(): raise RuntimeError('would overwrite existing integration file:'+str(relative))
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
        copied[relative.as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
subprocess.run(['python','-B','tools/verify_artifacts.py','--write'],cwd=DEST,check=True)
out=DEST/'build/role-policy-v2'
out.mkdir(parents=True,exist_ok=True)
(out/'candidate-composition.json').write_bytes((json.dumps({'source_parent':'4799a7260d8f99e489541cffe471e53c50411459',
    'composed_parent':head,'base':'25f7c45f20cfd4f892f7387cd3d3842105d8b214','copied':copied},indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'copied_files':len(copied),'composition_parent':head}))
