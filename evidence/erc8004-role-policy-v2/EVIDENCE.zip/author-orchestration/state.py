import json
from datetime import datetime,timezone
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
REPO='trustless-ai/verifiable-execution-claim-authorization'
def gh(*args):return json.loads(subprocess.check_output(['gh',*args]))
pr=gh('pr','view','10','--repo',REPO,'--json','number,url,title,headRefName,headRefOid,baseRefName,baseRefOid,isDraft,state,mergedAt,body')
refs=subprocess.check_output(['git','ls-remote','origin','refs/heads/main','refs/heads/feat/agent-conformance-harness-v0',
    'refs/heads/research/erc8004-property-fuzz-v0','refs/heads/research/spec-drift-obligation-coverage-v0'],cwd=ROOT,text=True)
record={'utc':datetime.now(timezone.utc).isoformat(),'pr':pr,'protected_refs':dict(line.split()[::-1] for line in refs.splitlines())}
path=HERE/'PREFLIGHT.json'
if path.exists():raise RuntimeError('preflight already captured')
path.write_bytes((json.dumps(record,indent=2,sort_keys=True)+'\n').encode())
notes=ROOT/'build/role-policy-v2/DEVELOPMENT_NOTES.json'
notes.write_bytes((json.dumps({'development_smoke':{'exit_code':0,'cases':50,'scope':'pre-final v2 source'},
    'development_mutations':{'exit_code':1,'semantic_records':'5 KILLED on the pre-final source copy',
    'closure':'NOT_PASSED','reason':'While this preliminary campaign used isolated copies, the author refined the source missing-call classification. The final source-preservation guard correctly detected the changed original source and exited 1. These records are not final evidence; final campaigns start after code freeze.'}},indent=2,sort_keys=True)+'\n').encode())
print(json.dumps({'head':pr['headRefOid'],'draft':pr['isDraft'],'protected_refs':record['protected_refs']}))
