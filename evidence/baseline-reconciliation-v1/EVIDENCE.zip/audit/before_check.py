import hashlib, json, subprocess
from pathlib import Path
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')
OUT=Path(__file__).resolve().parent
ref='80c91a09095eca362dbfb69d39d0c01fc31130cf'
raw=subprocess.check_output(['git','show',ref+':tools/erc8004/integrity.py'],cwd=ROOT)
ns={'__file__':str(ROOT/'tools/erc8004/integrity.py'),'__name__':'historical_integrity'}
exec(compile(raw,'historical_integrity.py','exec'),ns)
result=ns['check']()
expected=['baseline:conformance/agent-harness-v0/README.md','baseline:research/harness-v0/LIMITATIONS.md']
if result['passed'] or result['mismatches']!=expected:raise RuntimeError('unexpected old-checker failure')
record={'historical_checker_commit':ref,'historical_checker_sha256':hashlib.sha256(raw).hexdigest(),
        'mode':'read-only execution of exact historical source against composed checkout',
        'result':result,'expected_failure_confirmed':True}
(OUT/'HISTORICAL_CHECKER_FAILURE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(record))
