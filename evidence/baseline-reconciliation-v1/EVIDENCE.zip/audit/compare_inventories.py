import hashlib, json, subprocess
from pathlib import Path
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
OUT=Path(__file__).resolve().parent
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
old='0e17c97e896916b4d9505072cc9ebe2018329b01'
review='e5263f47325a81b0647f3de3a7bc36ad858aea5a'
base='25f7c45f20cfd4f892f7387cd3d3842105d8b214'
pilot='80c91a09095eca362dbfb69d39d0c01fc31130cf'
head='aee0f9fe9aab1c90807846a6e37999be27265af2'
merge='a6e0c6011a92c78b34ed929e992e444912a891cb'
manifests={ref:json.loads(git('show',ref+':artifacts.sha256.json'))['files'] for ref in [old,review,base,pilot,head,merge]}
def compare(a,b):
    before,after=manifests[a],manifests[b]
    return {'from':a,'to':b,'before_count':len(before),'after_count':len(after),
            'changed':{p:{'before':before[p],'after':after[p]} for p in before.keys() & after.keys() if before[p]!=after[p]},
            'removed':sorted(before.keys()-after.keys()),'added':{p:after[p] for p in sorted(after.keys()-before.keys())}}
report={'comparisons':[compare(old,review),compare(review,base),compare(pilot,head),compare(head,merge)],
        'pr11_and_pr9_trees_equal':git('rev-parse',review+'^{tree}')==git('rev-parse',base+'^{tree}'),
        'historical_manifest_sha256':{r:hashlib.sha256(git('show',r+':artifacts.sha256.json')).hexdigest() for r in manifests}}
(OUT/'INVENTORY_COMPARISON.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf8',newline='\n')
print(json.dumps(report,indent=2))
