import hashlib, json, subprocess
from pathlib import Path
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
HERE=Path(__file__).resolve().parent
PARENT='aee0f9fe9aab1c90807846a6e37999be27265af2'
BRANCH='feat/agent-harness-erc8004-v0'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode().strip()
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
require(git('rev-parse','HEAD')==PARENT,'unexpected local HEAD')
require(git('branch','--show-current')==BRANCH,'wrong branch')
remote=git('ls-remote','origin','refs/heads/'+BRANCH)
require(remote.split()[0]==PARENT,'remote branch advanced')
require(git('ls-remote','origin','refs/heads/feat/agent-conformance-harness-v0').split()[0]=='25f7c45f20cfd4f892f7387cd3d3842105d8b214','base changed')
summary=json.loads((ROOT/'evidence/baseline-reconciliation-v1/SUMMARY.json').read_bytes())
require(summary['passed'],'evidence gate failed')
for name,digest in summary['tested_candidate_code_sha256'].items():
    require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'tested code changed: '+name)
allowed=['artifacts.sha256.json','tools/erc8004/integrity.py','tools/erc8004_role_policy/integrity.py',
         'tools/baseline_reconciliation','tests/baseline_reconciliation',
         'research/baseline-reconciliation-v1','evidence/baseline-reconciliation-v1',
         '.github/workflows/baseline-reconciliation.yml']
changed=set(git('diff','HEAD','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
require(all(any(p==a or p.startswith(a+'/') for a in allowed) for p in changed),'unexpected changed path')
for name in changed:
    if Path(name).suffix in ('.py','.json','.md','.yml','.diff'):
        require(b'\r' not in (ROOT/name).read_bytes(),'non-LF text: '+name)
subprocess.run(['python','-B','tools/verify_artifacts.py'],cwd=ROOT,check=True)
git('diff','--check')
git('add','--',*allowed)
git('diff','--cached','--check')
print(git('diff','--cached','--stat'))
print(git('commit','-m','fix: reconcile exact PR11 baseline with preserved evidence'))
head=git('rev-parse','HEAD')
record={'branch':BRANCH,'parent':PARENT,'head':head,'tree':git('rev-parse','HEAD^{tree}'),
        'changed_paths':sorted(changed),'archive_sha256':json.loads((ROOT/'evidence/baseline-reconciliation-v1/SHA256.json').read_bytes())['archive_sha256']}
(HERE/'COMMIT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(record,indent=2))
