import json, subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
TARGET=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')
record=json.loads((HERE/'COMMIT.json').read_bytes())
base='25f7c45f20cfd4f892f7387cd3d3842105d8b214'
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
tree=git(AUTHOR,'merge-tree','--write-tree',base,record['head']).splitlines()[0]
git(TARGET,'add','--',*record['changed_paths'])
git(TARGET,'diff','--cached','--check')
tested=git(TARGET,'write-tree')
if tested!=tree:raise RuntimeError('tested composition differs from Git merge tree')
result={'passed':True,'head':record['head'],'base':base,'expected_merge_tree':tree,
        'tested_candidate_tree':tested,'operation':'git merge-tree and index tree comparison; no branch merge'}
(HERE/'COMPOSITION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(result))
