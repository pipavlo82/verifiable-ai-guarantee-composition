import json, subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
REPO='trustless-ai/verifiable-execution-claim-authorization'
commit=json.loads((HERE/'COMMIT.json').read_bytes())
raw=subprocess.check_output(['gh','pr','view','10','--repo',REPO,'--json','body,headRefOid,baseRefName,isDraft,state,url'])
pr=json.loads(raw)
if pr['headRefOid']!=commit['head'] or not pr['isDraft'] or pr['state']!='OPEN':raise RuntimeError('unexpected PR state')
(HERE/'PR_BEFORE.json').write_bytes(raw)
(HERE/'PR_BODY_BEFORE.md').write_text(pr['body'],encoding='utf8',newline='\n')
head=commit['head'];base='25f7c45f20cfd4f892f7387cd3d3842105d8b214'
url='https://github.com/'+REPO+'/blob/'+head+'/'
section=f'''## Baseline reconciliation v1 — reviewed PR11 documentation transition

Exact head: `{head}`. Current base branch: `{pr['baseRefName']}` at
`{base}`. Parent before this update: `{commit['parent']}`.
This remains a Draft; no branch merge, main update, or #12/#13 head change.

The inherited ERC-8004 PR gate failed on two exact #11 documentation additions.
Compared both files' complete SHA-256, Git blobs and histories, then replayed the
four supplemental witnesses **before** reconciling the baseline. Their guards
are `scope`, `scenario`, `definitions`, and `supported_contract`, all research
policy boundaries. Correct refusal stays REFUTED while conformance is PASS.

The new `veca-pr11-baseline-reconciliation-v1` preservation rule accepts only
the two original documents or the exact #11 pair **with all 13 exact supplemental
files**. It checks pinned historical inventories, rejects mixed/rehashed/missing
states, and separately identifies the hashed integrity-checker update. The
original source locks, normative pins, execution expectations, ERC-8404 Core,
harness/grader, and historical evidence are unchanged. Historical reports are
not resealed. The source branch retains old doc bytes; the PR merge tree contains
the reviewed #11 additions and both test populations.

Executed local source-tree and isolated composed-tree gates:

- Original ERC-8004: **29/29** normal/repeat/-O, byte-identical to frozen evidence;
  separate original physical population **17/17 KILLED** in normal and -O.
- Role policy v1: **26/26**, separate **7/7 KILLED**, **18/18** controls, normal/-O.
- Composed ERC-8404 harness: **18/18**, separate original **12/12 KILLED**, normal/-O.
- Supplemental #11: **5/5**, separate **4/4 KILLED**, normal/repeat/-O. Positive
  controls and physical/semantic restoration pass. The old five-probe comparison
  remains **1 KILLED / 4 SURVIVED**; populations are not combined.
- Baseline transition controls: **16/16** normal and -O on both trees.

Evidence archive SHA-256: `{commit['archive_sha256']}`.
The actual tested candidate tree is compared with `git merge-tree` for this exact
head and base. GitHub CI is tracked separately in this PR's Checks; the local
counts above are not represented as GitHub or independent organizational results.
The added workflow uses the actual PR merge checkout; existing workflows are
unchanged. No universal compliance, independent-controller or merge approval claim.

[Comparison, exact hashes and replay commands]({url}research/baseline-reconciliation-v1/README.md) ·
[Executed results]({url}research/baseline-reconciliation-v1/RESULTS.md) ·
[Machine summary]({url}evidence/baseline-reconciliation-v1/SUMMARY.json) ·
[Archive and member hashes]({url}evidence/baseline-reconciliation-v1/SHA256.json)

Independent review should check the two source diffs and pinned manifests, reject
arbitrary document rehashing or partial supplemental payload, replay the four
physical guards, compare the preserved 29-case digest, and review the exact PR
merge checkout's checks. #12/#13 still need their own later integration validation.

Earlier integration-warning paragraphs below describe the preceding head. They
are superseded only for this explicitly bounded and replayed document transition.

---

'''
(HERE/'PR_BODY_AFTER.md').write_text(section+pr['body'],encoding='utf8',newline='\n')
subprocess.run(['gh','pr','edit','10','--repo',REPO,'--body-file',str(HERE/'PR_BODY_AFTER.md')],check=True)
print(pr['url'])
