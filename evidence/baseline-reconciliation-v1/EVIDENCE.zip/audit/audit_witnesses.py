import hashlib, json
from pathlib import Path
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-pr9-final-audit-20261023')
RUN=ROOT/'build/baseline-reconciliation-20261024/review'
OUT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
summary=json.loads((RUN/'summary.json').read_bytes())
require(summary['passed'],'validation failed')
results={}
for mode in ('normal','optimized'):
    report=json.loads((RUN/mode/'report.json').read_bytes())
    require(report['isolated']['counts']=={'KILLED':4},'incomplete supplemental kills')
    require(report['original_18']['counts']=={'KILLED':1,'SURVIVED':4},'historical distinction lost')
    rows=[]
    for record in report['isolated']['mutations']:
        guard=record['guard'];folder=RUN/mode/'isolated'/guard
        phases={p:json.loads((folder/p/'report.json').read_bytes()) for p in ('baseline','mutant','restored')}
        witness=guard+'_only'
        for phase in ('baseline','restored'):
            row=next(r for r in phases[phase]['rows'] if r['id']==witness)
            require(row['backend_conformance']=='PASS' and row['observed_behavior']['authorization']['status']=='REFUTED','refusal mismatch')
            checks=row['evidence']['decision']['checks']
            require({k:v for k,v in checks.items() if v!='VERIFIED'}=={guard:'REFUTED'},'not isolated')
        mutant=next(r for r in phases['mutant']['rows'] if r['id']==witness)
        require(mutant['backend_conformance']=='FAIL' and mutant['observed_behavior']['authorization']['authorized'] is True,'not a semantic kill')
        for phase in phases:
            positive=next(r for r in phases[phase]['rows'] if r['id']=='permitted_review')
            require(positive['backend_conformance']=='PASS','positive control failed')
        require(record['original_sha256']==record['restored_sha256']!=record['mutant_sha256'],'no physical restoration')
        require((folder/'baseline/projected.json').read_bytes()==(folder/'restored/projected.json').read_bytes(),'semantic restoration failed')
        requests=[json.loads((folder/p/'request.json').read_bytes()) for p in phases]
        require(requests[0]==requests[1]==requests[2],'inputs changed')
        for request in requests:
            require(set(request)=={'schema','profile','cases'} and all(set(c)=={'id','input'} for c in request['cases']),'expected outcomes supplied')
        rows.append(record)
    results[mode]=rows
require(results['normal']==results['optimized'],'mutations differ')
projections=[(RUN/m/r/'projected.json').read_bytes() for m in ('normal','optimized') for r in ('normal','repeat')]
require(len(set(projections))==1,'replay differs')
result={'passed':True,'source_head':'25f7c45f20cfd4f892f7387cd3d3842105d8b214','pr11_source':'e5263f47325a81b0647f3de3a7bc36ad858aea5a',
        'scenarios':5,'guards':['scope','scenario','definitions','supported_contract'],
        'modes':results,'behavioral_sha256':sha(projections[0]),'historical_probe_counts':{'KILLED':1,'SURVIVED':4},
        'independent_organizational_review':'NOT_COVERED'}
(OUT/'WITNESS_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'passed':True,'guards':result['guards'],'behavioral_sha256':result['behavioral_sha256']}))
