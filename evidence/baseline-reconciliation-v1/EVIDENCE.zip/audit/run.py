import hashlib, json, subprocess, sys, time
from pathlib import Path

ROOT=Path(sys.argv[1]).resolve()
GROUP=sys.argv[2]
OUT=ROOT/'build/baseline-reconciliation-20261024'/GROUP
OUT.mkdir(parents=True,exist_ok=True)
commands=[]
def run(name,args,opt=False):
    argv=[sys.executable,'-B',*(['-O'] if opt else []),*args]
    start=time.time()
    proc=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=5400)
    (OUT/(name+'.stdout')).write_bytes(proc.stdout)
    (OUT/(name+'.stderr')).write_bytes(proc.stderr)
    commands.append({'name':name,'argv':argv,'cwd':str(ROOT),'exit_code':proc.returncode,'seconds':time.time()-start,
                     'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(proc.stderr).hexdigest()})
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8',newline='\n')
    print(name,proc.returncode,flush=True)
    if proc.returncode:raise RuntimeError(name+' failed; see raw logs')

if GROUP=='supplemental':
    run('review',['tools/harness_v0/review_validate.py','--out',str(OUT/'review')])
elif GROUP=='harness':
    run('harness',['tools/harness_v0/validate.py','--out',str(OUT/'harness')])
    run('mutations-optimized',['tools/harness_v0/mutations.py','--out',str(OUT/'mutations-optimized')],True)
else:
    run('controls-normal',['-m','unittest','discover','-s','tests/baseline_reconciliation','-v'])
    run('controls-optimized',['-m','unittest','discover','-s','tests/baseline_reconciliation','-v'],True)
    run('inventory-before',['tools/verify_artifacts.py'])
    run('legacy',['tools/erc8004/validate.py','--out',str(OUT/'legacy')])
    run('legacy-mutants-optimized',['tools/erc8004/mutations.py','--out',str(OUT/'legacy-mutants-optimized')],True)
    run('role-policy',['tools/erc8004_role_policy/validate.py','--out',str(OUT/'role-policy')])
    run('inventory-after',['tools/verify_artifacts.py'])
(OUT/'COMPLETED.json').write_text(json.dumps({'passed':True,'group':GROUP,'commands':commands},indent=2)+'\n',encoding='utf8',newline='\n')
