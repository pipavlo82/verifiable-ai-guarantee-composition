import hashlib, json, subprocess
from pathlib import Path

ROOT = Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
OUT = Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)
refs = {
    'original_harness': '0e17c97e896916b4d9505072cc9ebe2018329b01',
    'historical_pilot': '80c91a09095eca362dbfb69d39d0c01fc31130cf',
    'pr11': 'e5263f47325a81b0647f3de3a7bc36ad858aea5a',
    'integrated_pr9': '25f7c45f20cfd4f892f7387cd3d3842105d8b214',
    'current_pr10': 'aee0f9fe9aab1c90807846a6e37999be27265af2',
    'github_test_merge': 'a6e0c6011a92c78b34ed929e992e444912a891cb',
}
paths = ['conformance/agent-harness-v0/README.md', 'research/harness-v0/LIMITATIONS.md']
report = {'refs': refs, 'files': {}}
for path in paths:
    records = {}
    for label, ref in refs.items():
        raw = git('show', ref + ':' + path)
        dest = OUT / 'source-bytes' / label / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        records[label] = {'commit': ref, 'git_blob': git('rev-parse', ref + ':' + path).decode().strip(),
                          'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    report['files'][path] = records
    report.setdefault('history', {})[path] = git('log', refs['pr11'], '--format=%H %s', '--', path).decode().splitlines()
diff = git('diff', '--unified=0', refs['original_harness'], refs['pr11'], '--', *paths)
(OUT / 'documentation.diff').write_bytes(diff)
(OUT / 'DOCUMENT_COMPARISON.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report, indent=2))
