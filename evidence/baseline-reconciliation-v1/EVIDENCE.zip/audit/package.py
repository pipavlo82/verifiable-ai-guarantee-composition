import hashlib, json, platform, re, shutil, subprocess, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path

HERE=Path(__file__).resolve().parent
AUTHOR=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
INTEGRATION=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')
PRE=Path('D:/PAVLO HQ/Workspaces/veca-pr9-final-audit-20261023/build/baseline-reconciliation-20261024/review')
RUN='build/baseline-reconciliation-20261024'
EVIDENCE=AUTHOR/'evidence/baseline-reconciliation-v1'
DOCS=AUTHOR/'research/baseline-reconciliation-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n',encoding='utf8',newline='\n')
def mutation_count(p,n):
    r=read(p)
    require(r['counts'].get('KILLED')==n and sum(r['counts'].values())==n,str(p))
    return r

for root,groups in [(AUTHOR,['author']),(INTEGRATION,['integration','harness','supplemental'])]:
    for group in groups:
        require(read(root/RUN/group/'COMPLETED.json')['passed'],'incomplete group '+group)
for name in ('WITNESS_AUDIT.json','HISTORICAL_CHECKER_FAILURE.json'):
    shutil.copyfile(HERE/name,DOCS/name)

source_reports={}
expected_legacy=(AUTHOR/'evidence/erc8004-pilot-v0/local-replay/normal/projected.json').read_bytes()
for label,root in [('author',AUTHOR),('integration',INTEGRATION)]:
    out=root/RUN/label
    legacy=read(out/'legacy/summary.json');roles=read(out/'role-policy/summary.json')
    require(legacy['passed'] and legacy['scenarios']==legacy['conformant']==29,'legacy cases')
    require(roles['passed'] and roles['cases']==roles['conformant']==26,'role cases')
    m=mutation_count(out/'legacy/mutations/report.json',17)
    mo=mutation_count(out/'legacy-mutants-optimized/report.json',17)
    require(m==mo,'legacy mutation mode disagreement')
    require(roles['physical_mutations'].get('KILLED')==7 and roles['mutation_modes_equal'],'role mutations')
    require(roles['controls']=={'normal':18,'optimized':18},'role infrastructure count')
    digests={}
    for mode in ('normal','repeat','optimized'):
        raw=(out/'legacy'/mode/'projected.json').read_bytes()
        require(raw==expected_legacy,'legacy differs from preserved pilot evidence')
        digests[mode]=sha(raw)
    for mode in ('normal','optimized'):
        text=(out/('controls-'+mode+'.stderr')).read_text()
        require(re.search(r'Ran 16 tests',text) and text.rstrip().endswith('OK'),'baseline controls')
    source_reports[label]={'legacy':{k:legacy[k] for k in ('passed','scenarios','conformant','mutations','semantic_determinism')},
                           'legacy_behavioral_sha256':digests,'roles':roles,
                           'legacy_integrity':read(out/'legacy/integrity-after.stdout'),
                           'role_integrity':read(out/'role-policy/preservation-after.stdout'),
                           'baseline_controls':{'normal':16,'optimized':16}}
require(source_reports['author']['roles']['behavioral_sha256']==source_reports['integration']['roles']['behavioral_sha256'],'source/merge role mismatch')
require(set(source_reports['author']['roles']['behavioral_sha256'].values())=={'0ed522131509603602adbb90d8c6111a3347d8b5c19ce90d75440c67953a7617'},'frozen role behavior changed')
harness=read(INTEGRATION/RUN/'harness/harness/summary.json')
require(harness['passed'] and harness['scenario_count']==harness['conformant_scenarios']==18,'harness scenarios')
for mode in ('normal','repeat','optimized'):
    raw=(INTEGRATION/RUN/'harness/harness'/mode/'projected.json').read_bytes()
    require(sha(raw)=='1c12db717dc43d6b9568b902089cde8906e53951aa2ccf22e4b04404620a106b','original 18 behavior changed')
mutation_count(INTEGRATION/RUN/'harness/harness/mutations/report.json',12)
mutation_count(INTEGRATION/RUN/'harness/mutations-optimized/report.json',12)
review=read(INTEGRATION/RUN/'supplemental/review/summary.json')
require(review['passed'] and review['isolated_mutation_counts']=={'KILLED':4},'supplemental failures')
review_digests={}
for mode in ('normal','optimized'):
    r=read(INTEGRATION/RUN/'supplemental/review'/mode/'report.json')
    prior=read(PRE/mode/'report.json')
    require(r['isolated']==prior['isolated'] and r['original_18']==prior['original_18'],'PR11 records changed')
    for repeat in ('normal','repeat'):
        raw=(INTEGRATION/RUN/'supplemental/review'/mode/repeat/'projected.json').read_bytes()
        require(raw==(PRE/mode/repeat/'projected.json').read_bytes(),'PR11 semantics changed')
        review_digests[mode+'/'+repeat]=sha(raw)
code_paths=['tools/erc8004/integrity.py','tools/erc8004_role_policy/integrity.py',
            'tools/baseline_reconciliation/policy.py','tests/baseline_reconciliation/test_policy.py',
            '.github/workflows/baseline-reconciliation.yml']
code={p:sha((AUTHOR/p).read_bytes()) for p in code_paths}
require(all((AUTHOR/p).read_bytes()==(INTEGRATION/p).read_bytes() for p in code_paths),'tested code mismatch')
summary={'schema':'veca.baseline-reconciliation.execution.v1','passed':True,'observed_utc':datetime.now(timezone.utc).isoformat(),
         'author_parent':'aee0f9fe9aab1c90807846a6e37999be27265af2',
         'integration_parent':'a6e0c6011a92c78b34ed929e992e444912a891cb',
         'tested_candidate_code_sha256':code,'source_and_composed_runs':source_reports,
         'supplemental_behavioral_sha256':review_digests,
         'supplemental_guards':['scope','scenario','definitions','supported_contract'],
         'supplemental_mutations':{'normal':{'KILLED':4},'optimized':{'KILLED':4}},
         'original_18_probe_comparison':review['reviewer_experiment_counts'],
         'harness':{k:harness[k] for k in ('passed','scenario_count','conformant_scenarios','mutations','authorization_counts','deterministic_normal_repeat_optimized')},
         'environment':{'python':sys.version,'platform':platform.platform(),'node':subprocess.check_output(['node','--version'],text=True).strip()},
         'independent_organizational_replay':'NOT_COVERED','merge_authorization':False,
         'historical_manifest_and_evidence_rewritten':False}
write(EVIDENCE/'SUMMARY.json',summary)
members={}
def add_tree(prefix,folder,select=lambda p:True):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and select(p):members[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
add_tree('pr11-before-reconciliation',PRE)
add_tree('composed',INTEGRATION/RUN)
# Keep full composed raw evidence, and source-head command/results/projections;
# repeated source-head raw mutation observations are redundant with that replay.
add_tree('source-head',AUTHOR/RUN/'author',lambda p:p.name in ('commands.json','summary.json','report.json','COMPLETED.json','projected.json') or p.parent==AUTHOR/RUN/'author')
add_tree('audit',HERE,lambda p:p.suffix in ('.py','.json','.diff') and 'source-bytes' not in p.parts)
add_tree('historical-document-bytes',HERE/'source-bytes')
for path in code_paths:members['tested-code/'+path]=(AUTHOR/path).read_bytes()
members['summary.json']=(EVIDENCE/'SUMMARY.json').read_bytes()
EVIDENCE.mkdir(parents=True,exist_ok=True)
archive=EVIDENCE/'EVIDENCE.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16;z.writestr(info,raw)
seal={'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
      'summary_sha256':sha((EVIDENCE/'SUMMARY.json').read_bytes()),'members':{p:sha(b) for p,b in sorted(members.items())}}
write(EVIDENCE/'SHA256.json',seal)
with zipfile.ZipFile(archive) as z:
    require(set(z.namelist())==set(seal['members']),'archive member set')
    require(all(sha(z.read(p))==h for p,h in seal['members'].items()),'archive hash')
(EVIDENCE/'README.md').write_text('''# Baseline reconciliation execution evidence

New author-operated Windows runs, separate from all frozen historical packages.
SUMMARY.json identifies the tested source files and source/merge parent commits.
EVIDENCE.zip preserves exact document bytes, comparisons, commands, stdout/stderr,
baseline/mutant/restored observations, positive controls and source identities.
SHA256.json records archive and member hashes. ZIP order/timestamps are fixed;
raw runtime timing/path metadata is preserved, so separate executions need not
have identical archive hashes. Build caches and installed dependencies are absent.

These are candidate-tree results, not a claim of independent organizational review
or GitHub CI. The PR records the final commit and later exact-head CI separately.
Reproduction commands: ../../research/baseline-reconciliation-v1/README.md.
''',encoding='utf8',newline='\n')
(DOCS/'RESULTS.md').write_text(f'''# Executed baseline reconciliation results

The read-only comparison identified exactly two documentation transitions from
#11. Both full file SHA-256 values, Git blobs, commit histories and original bytes
are preserved. Re-executing the exact historical integrity checker against the
composed tree reproduced exactly those two failures before reconciliation.

Before accepting the transition, the unchanged #11 checkout at `25f7c45f` was
replayed: scope, scenario, definitions and supported_contract each had an isolated
REFUTED witness that was a conformance PASS, a passing positive control, a physical
KILLED mutant and byte-exact/semantic restoration. Normal/repeat/-O agreed.
The five-probe comparison on the old 18 vectors remains 1 KILLED / 4 SURVIVED.

The following were actually executed with the same reconciliation code on the
source-head candidate and on the isolated GitHub test-merge candidate:

| Population | Source candidate | Composed candidate |
| --- | --- | --- |
| Original ERC-8004 scenarios | 29/29 normal/repeat/-O | 29/29 normal/repeat/-O |
| Original ERC-8004 physical mutations | 17/17 normal and -O | 17/17 normal and -O |
| Role-policy v1 scenarios | 26/26 normal/repeat/-O | 26/26 normal/repeat/-O |
| Role-policy v1 physical mutations | 7/7 normal and -O | 7/7 normal and -O |
| Role-policy infrastructure methods | 18/18 normal and -O | 18/18 normal and -O |
| Baseline transition controls | 16/16 normal and -O | 16/16 normal and -O |

On the composed checkout the original ERC-8404 harness also passed 18/18 in
normal/repeat/-O, with its separate original 12/12 physical mutations in normal
and -O. The supplemental profile passed 5/5, with its separate 4/4 mutations in
normal and -O, matching the pre-reconciliation raw mutation records and semantic
projections. These mutation populations are not added together.

Original 29-case projections match the preserved pilot evidence byte for byte:
`{sha(expected_legacy)}`. Role-policy projections retain
`0ed522131509603602adbb90d8c6111a3347d8b5c19ce90d75440c67953a7617`.
Supplemental projections retain
`aa134ea900784fbb4f69d972babafa1b579b64e16771de554f906ef47dd909cc`.

The original 12,193-entry harness inventory has 12,191 unchanged files in the
composition plus exactly two reviewed document transitions. Relative to the
12,667-entry pilot inventory, 12,664 are unchanged in that composition: two docs
and the explicitly versioned preservation-checker update are listed separately.
On the source candidate the docs stay original, leaving 12,666 pilot files
unchanged plus the checker transition. All original source locks, normative pins,
Solidity, harness/grader, expectations, and frozen evidence remain byte-identical.
The role-policy preservation entry point is also deliberately updated to invoke
the versioned check; it is not falsely counted as unchanged from `aee0f9f`.

The archive SHA-256 is `{seal['archive_sha256']}`
({len(members)} members, {seal['archive_bytes']} bytes). See
../../evidence/baseline-reconciliation-v1/SUMMARY.json for exact candidate source
hashes, runtime versions and machine results. The raw evidence includes all
completed command receipts. Missing history, wrong manifests, rehashed corruption,
mixed document versions and incomplete PR11 payloads fail the negative controls.

Recommendation: READY_FOR_INDEPENDENT_REVIEW for this bounded reconciliation.
This does not authorize merge, claim universal conformance or establish independent
human/controller validation. PR #10 stays Draft. #12/#13 require their own later
integration checks and have not been changed. Existing frozen reports retain
their original meaning; new CI results are recorded separately on the PR.
''',encoding='utf8',newline='\n')
print(json.dumps({'passed':True,'archive_sha256':seal['archive_sha256'],'members':len(members),'bytes':seal['archive_bytes']}))
