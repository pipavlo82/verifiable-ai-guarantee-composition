import hashlib, json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('D:/PAVLO HQ/Workspaces/veca-role-policy-fresh-20261024')
OUT=HERE/'fresh'
OUT.mkdir(exist_ok=True)
head=json.loads((HERE/'COMMIT.json').read_bytes())['head']
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode().strip()
if git('status','--porcelain'):raise RuntimeError('fresh checkout has changes; preserve them')
git('fetch','origin',head)
git('checkout','--detach',head)
if git('rev-parse','HEAD')!=head:raise RuntimeError('wrong fresh HEAD')
commands=[]
def run(name,args,opt=False):
    argv=[sys.executable,'-B',*(['-O'] if opt else []),*args]
    p=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=900)
    (OUT/(name+'.stdout')).write_bytes(p.stdout);(OUT/(name+'.stderr')).write_bytes(p.stderr)
    commands.append({'name':name,'argv':argv,'cwd':str(ROOT),'exit_code':p.returncode,
                     'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8',newline='\n')
    if p.returncode:raise RuntimeError(name+' failed')
    print(name,0,flush=True)
run('inventory',['tools/verify_artifacts.py'])
for mode,opt in [('normal',False),('optimized',True)]:
    run('controls-'+mode,['-m','unittest','discover','-s','tests/baseline_reconciliation','-v'],opt)
    run('integrity-'+mode,['tools/erc8004/integrity.py'],opt)
    run('role-preservation-'+mode,['tools/erc8004_role_policy/integrity.py'],opt)
for profile,label in [('erc8004-pilot-v0','legacy'),('erc8004-role-policy-v1','roles')]:
    run(label,['tools/agent_harness.py','run','--suite','conformance/'+profile+'/suite.json',
               '--adapter','conformance/'+profile+'/adapter.json','--out','build/baseline-exact-commit/'+label])
    p=ROOT/'build/baseline-exact-commit'/label
    for filename in ['report.json','projected.json','request.json','adapter.stdout','adapter.stderr']:
        (OUT/(label+'-'+filename)).write_bytes((p/filename).read_bytes())
if git('status','--porcelain'):raise RuntimeError('fresh checkout changed')
result={'passed':True,'head':head,'tree':git('rev-parse','HEAD^{tree}'),'clean':True,
        'scope':'new baseline controls and both preservation checks normal/-O; one 29-case and one 26-case replay',
        'dependency_preparation':'Reused this separately cloned checkout\'s already prepared pinned caches; both source/dependency checks rerun. No fresh download claimed.',
        'independent_organizational_replay':'NOT_COVERED','commands':commands}
(HERE/'FRESH.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'passed':True,'head':head,'clean':True}))
