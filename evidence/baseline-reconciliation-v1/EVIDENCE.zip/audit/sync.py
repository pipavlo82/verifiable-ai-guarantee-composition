import json, shutil, subprocess
from pathlib import Path
SOURCE=Path('D:/PAVLO HQ/Workspaces/veca-erc8004-validator-policy-20261024')
TARGET=Path('D:/PAVLO HQ/Workspaces/veca-baseline-integration-20261024')
HERE=Path(__file__).resolve().parent
paths=['tools/erc8004/integrity.py','tools/erc8004_role_policy/integrity.py',
       'tools/baseline_reconciliation/policy.py','tests/baseline_reconciliation/test_policy.py',
       '.github/workflows/baseline-reconciliation.yml']
for name in ['DOCUMENT_COMPARISON.json','INVENTORY_COMPARISON.json','documentation.diff']:
    path=SOURCE/'research/baseline-reconciliation-v1'/name
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(HERE/name,path)
paths += [p.relative_to(SOURCE).as_posix() for p in (SOURCE/'research/baseline-reconciliation-v1').rglob('*') if p.is_file()]
paths += [p.relative_to(SOURCE).as_posix() for p in (SOURCE/'evidence/baseline-reconciliation-v1').rglob('*') if p.is_file()]
for path in paths:
    dest=TARGET/path;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(SOURCE/path,dest)
for root in (SOURCE,TARGET):
    subprocess.run(['python','-B','tools/verify_artifacts.py','--write'],cwd=root,check=True)
    subprocess.run(['git','diff','--check'],cwd=root,check=True)
print(json.dumps({'synchronized':paths,'source':str(SOURCE),'target':str(TARGET)}))
